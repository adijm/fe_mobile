// return_list_screen.dart
import 'package:flutter/material.dart';
import 'return_screen.dart';
import '../services/api_service.dart';

class ReturnListScreen extends StatelessWidget {
  const ReturnListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Pengembalian'),
        backgroundColor: Colors.green,
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: ApiService.fetchPeminjamanAktif(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final data = snapshot.data ?? [];

          if (data.isEmpty) {
            return const Center(child: Text('Tidak ada buku yang dipinjam.'));
          }

          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              final item = data[index];
return ListTile(
  title: Text(item['judul'] ?? 'Tanpa Judul'),
  subtitle: Text('Tenggat: ${item['tenggat'] ?? '-'}'),
  trailing: Text(
    item['status'] ?? 'tidak diketahui',
    style: TextStyle(
      color: item['status'] == 'terlambat' ? Colors.red : Colors.orange,
    ),
  ),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReturnScreen(peminjamanId: item['id']),
      ),
    );
  },
);

            },
          );
        },
      ),
    );
  }
}
