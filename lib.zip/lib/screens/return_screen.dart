import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ReturnScreen extends StatefulWidget {
  final int peminjamanId;

  const ReturnScreen({super.key, required this.peminjamanId});

  @override
  State<ReturnScreen> createState() => _ReturnScreenState();
}

class _ReturnScreenState extends State<ReturnScreen> {
  int denda = 0;
  String status = 'Sedang Dipinjam';

  Future<void> _kembalikanBuku() async {
    final result = await ApiService.returnBook(widget.peminjamanId);
    if (result['success']) {
      setState(() {
        denda = result['denda'] ?? 0;
        status = result['status'] ?? 'dikembalikan';
      });

      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Berhasil'),
          content: Text(
            'Buku berhasil dikembalikan.\nDenda: Rp ${denda.toString()}',
            style: TextStyle(
              color: denda > 0 ? Colors.red : Colors.green[800],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            )
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gagal mengembalikan buku')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Return'),
        centerTitle: true,
        backgroundColor: const Color(0xFFB3D9F5),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar buku
            Container(
              width: 90,
              height: 130,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                image: const DecorationImage(
                  image: AssetImage('assets/images/rahasia_pelangi.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 16),
            // Detail teks
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Return Details',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF007041),
                    ),
                  ),
                  const SizedBox(height: 12),
                  detailText('Judul', 'Rahasia Pelangi'),
                  detailText('Penulis', 'Riawani Elyta & Shabrina Ws'),
                  iconTextRow(Icons.access_time, 'Periode Pinjam : 12 Hari'),
                  iconTextRow(Icons.date_range, 'Tanggal Pinjam : 24 Mei 2025'),
                  iconTextRow(Icons.calendar_today, 'Tanggal kembali : 5 Juni 2025'),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.circle, size: 12, color: Colors.orange),
                      const SizedBox(width: 4),
                      Text(
                        'Status : $status',
                        style: TextStyle(
                          fontSize: 13,
                          color: status == 'terlambat'
                              ? Colors.red
                              : status == 'dikembalikan'
                                  ? Colors.green
                                  : Colors.orange,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  if (denda > 0)
                    Text(
                      'Denda: Rp $denda',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: _kembalikanBuku,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          child: const Text('Kembalikan Buku'),
        ),
      ),
    );
  }

  Widget detailText(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 13, color: Colors.black),
          children: [
            TextSpan(
              text: '$label    ',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  Widget iconTextRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 14, color: Colors.grey[700]),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
